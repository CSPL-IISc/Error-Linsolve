clc;
clear all;


n = 50;
maxexp = 12;



    
    for i=1:maxexp

        [A,L] = matgen(n,exp(i),1);
        [U,S,V] = svd(A);
        condno(i) = cond(A);
        normA(i) = norm(A);
        normAinv(i) = condno(i)/normA(i);  
        
        for j=1:n
            b = U(:,j);
            x = A\b;
            kap_for(i,j) = normA(i)*norm(x);
            kap_back(i,j) = normAinv(i)/norm(x);
        end
    end





kap = exp(1:maxexp);



figure;
loglog(kap,condno);
xlabel('max singular value');
ylabel('condition number');
title('condition number analysis');


figure;
semilogy(1:n,kap_for(1,:));
hold on;
semilogy(1:n,kap_for(maxexp,:));
set(gca,'yscale','log');
xlabel('dimension number');
ylabel('forward condition number');
title('kappaF - Analysis');
legend('kappa = exp(12)','kappa = exp(1)');
hold off;

figure;
semilogy(1:n,kap_back(1,:));
hold on;
semilogy(1:n,kap_back(maxexp,:));
set(gca,'yscale','log');
xlabel('dimension number');
ylabel('backward condition number');
title('kappaB - Analysis');
legend('kappa = exp(12)','kappa = exp(1)');
hold off;


d = 5;
b = randn(n,1);
b = b/norm(b);
x = A\b;

[valg1, valg2, valg3, valg4] = gmres11(A,b,10^-6,zeros(n,1),x,d);

[val1,val2,val3,val4] = bicgtest(A,b,b,zeros(n,1),inv(A),d);