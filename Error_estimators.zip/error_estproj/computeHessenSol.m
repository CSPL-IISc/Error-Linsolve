function x = computeHessenSol(R,v,b)
n = length(b);
x = zeros(n,1);

for k=1:n-1
        b(k+1,1) = b(k+1,1) - v(k)*b(k,1);
end

for j = n:-1:2
        x(j,1) = b(j,1)/R(j,j);
        b(j-1,1) = b(j-1,1) - R(j-1,j:n)*x(j:n,1);
end
    x(1,1) = b(1,1)/R(1,1);

end