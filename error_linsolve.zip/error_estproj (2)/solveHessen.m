function x = solveHessen(H,b,type)

n = length(b);
x = zeros(n,1);

if strcmp(type,'lower')
    %LU step reducing to lower triangular system
    for k=n:-1:2
        v = H(k-1,k)/H(k,k);
        H(k-1,k) = 0;
        for j=k-1:-1:1
            H(k-1,j) = H(k-1,j) - v*H(k,j);
        end
        b(k-1,1) = b(k-1,1) - v*b(k,1);
    end
    
    for j=1:n-1
        x(j,1) = b(j,1)/H(j,j);
        b(j+1,1) = b(j+1,1) - H(j+1,1:j)*x(1:j,1);
    end
    x(n,1) = b(n,1)/H(n,n);
    
    
end

if strcmp(type,'upper')
    %LU step reducing to Upper triangular system
    for k=1:n-1
        v = H(k+1,k)/H(k,k);
        H(k+1,k) = 0;
        for j=k+1:n
            H(k+1,j) = H(k+1,j) - v*H(k,j);
        end
        b(k+1,1) = b(k+1,1) - v*b(k,1);
    end
    
    %back substitution
    for j = n:-1:2
        x(j,1) = b(j,1)/H(j,j);
        b(j-1,1) = b(j-1,1) - H(j-1,j:n)*x(j:n,1);
    end
    x(1,1) = b(1,1)/H(1,1);
    
end


end