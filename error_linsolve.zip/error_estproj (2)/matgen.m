function [A,L] = matgen(n,s,m)

A  = randn(n);
U1 = triu(A);
A=A+A';
b = randn(n,1);
[U V] = eig(A);

for i=1:length(b)
    if (V(i,i) < 0)
        V(i,i) = -V(i,i);
    end
end

A = U*V*inv(U)  ;%+ 0.01*U1;
[P L B] = svd(A);
for i=1:m
    L(i,i) = s*L(i,i); %stretch eigenvalues
end
A = P*L*B';
A = A - 0.2*randn(n); % to make nonsymmetric

end