function [R,v] = decomposeHessen(H)
n = length(H(:,1));
v = zeros(1,n-1);
%LU step reducing to Upper triangular system
    for k=1:n-1
        v(k) = H(k+1,k)/H(k,k);
        H(k+1,k) = 0;
        for j=k+1:n
            H(k+1,j) = H(k+1,j) - v(k)*H(k,j);
        end
    end
    R = H;
end