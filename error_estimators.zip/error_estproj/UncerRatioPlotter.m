%uncertainity ratio plotter

function[KAPPA,KAPPA_B,UR,URG,ITERELAPSED_BICG,TOL_1,TOL_2,TOL_3,TOL_4,UR_FOR_ERROR_BICG,URGforError_GMRES,URGforError_GMRES_Meurant,TOLG_1,TOLG_2,TOLG_3,TOLG_4] = UncerRatioPlotter(n, samples, maxA_norm, stretch_dimensions)

d=10; it = 1; m=1;
for j=1:1
    
    j
    
     
        [A,S] = matgen(n,maxA_norm,stretch_dimensions);
        
        
        
        INV_A = inv(A);
        NORM_A = norm(A);
        NORM_INVA = norm(INV_A);

       
       for iter = 1:samples
         if (mod(iter,100)==0)
             iter
             
         end
           
        
        b = randn(n,1);
        x = A\b;
        
        temp =  NORM_A*norm(x)/norm(b);
        temp2 = NORM_INVA*norm(b)/norm(x);
        
        if (temp > 10 || temp2 > 10) %check this when doing for gmres 

            kappa(m) = temp; %assume kappa as kappaf
            kappab(m) = temp2;
            [val1,val2,val3,val4] = bicgtest(A,b,b,zeros(n,1),INV_A,d);
            ur(m) = val1;
            urforerrorbicg(m) = val2;
            iterelapsed_bicg(m) = val3;
            tol_1(m) = val4(1); 
            tol_2(m) = val4(2); 
            tol_3(m) = val4(3); 
            tol_4(m) = val4(4); 
            %tol_5(m) = val4(5); 
            %tol_6(m) = val4(6);
            [valg1, valg2, valg3, valg4] = gmres11(A,b,10^-7,zeros(n,1),x,d);
            urG(m) = valg1; 
            urGforErrorgmres(m) = valg2;
            urGforErrorMeurantgrmes(m) = valg3;
            tolg_1(m) = valg4(1); 
            tolg_2(m) = valg4(2); 
            tolg_3(m) = valg4(3); 
            tolg_4(m) = valg4(4); 
            %tolg_5(m) = valg3(5); 
            %tolg_6(m) = valg3(6);
            m=m+1;
        
        end
        
       end
       
       
    

        
    if (j==1)
        UR = ur;
        URG = urG;
        URGforError_GMRES = urGforErrorgmres;
        URGforError_GMRES_Meurant = urGforErrorMeurantgrmes;
        KAPPA = kappa;
        KAPPA_B = kappab;
        ITERELAPSED_BICG = iterelapsed_bicg;
        UR_FOR_ERROR_BICG = urforerrorbicg;
        TOL_1 = tol_1; 
        TOL_2 = tol_2; 
        TOL_3 = tol_3; 
        TOL_4 = tol_4; 
        %TOL_5 = tol_5; 
        %TOL_6 = tol_6;
        TOLG_1 = tolg_1; 
        TOLG_2 = tolg_2; 
        TOLG_3 = tolg_3; 
        TOLG_4 = tolg_4; 
        %TOLG_5 = tolg_5; 
        %TOLG_6 = tolg_6;
    else 
        UR = [UR,ur];
        URG = [URG,urG];
        URGforError_GMRES = [URGforError_GMRES,urGforErrorgmres];
        URGforError_GMRES_Meurant = [URGforError_GMRES_Meurant,urGforErrorMeurantgrmes];
        KAPPA = [KAPPA,kappa];
        KAPPA_B = [KAPPA_B,kappab];
        ITERELAPSED_BICG = [ITERELAPSED_BICG,iterelapsed_bicg];
        UR_FOR_ERROR_BICG = [UR_FOR_ERROR_BICG,urforerrorbicg];
        TOL_1 = [TOL_1,tol_1]; 
        TOL_2 = [TOL_2,tol_2]; 
        TOL_3 = [TOL_3,tol_3]; 
        TOL_4 = [TOL_4,tol_4]; 
        %TOL_5 = [TOL_5,tol_5]; 
        %TOL_6 = [TOL_6,tol_6];
        TOLG_1 = [TOLG_1,tolg_1]; 
        TOLG_2 = [TOLG_2,tolg_2]; 
        TOLG_3 = [TOLG_3,tolg_3]; 
        TOLG_4 = [TOLG_4,tolg_4]; 
        %TOLG_5 = [TOLG_5,tolg_5]; 
        %TOLG_6 = [TOLG_6,tolg_6];      
    end

    
end


end